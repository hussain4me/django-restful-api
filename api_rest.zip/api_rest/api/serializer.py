from dataclasses import fields
from django.shortcuts import render
from django.http import HttpResponse
from rest_framework import serializers
from . models import Students,Studentclass


class Studentserializer(serializers.ModelSerializer):
    
    class Meta:
        model=Students
        
        fields = '__all__'


