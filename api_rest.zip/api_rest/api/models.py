from pyexpat import model
from django.db import models

# Create your models here.

class Students(models.Model):
    firstname=models.CharField(max_length=10)
    lastname=models.CharField(max_length=10)
    sex=models.CharField(max_length=10)
    dateofbirth = models.DateField()
    
    def __str__(self):
        return self.firstname
    
    
class Studentclass(models.Model):
    classtitle=models.CharField(max_length=10)
    no_of_student=models.IntegerField()
    # student_id=models.ForeignKey(model=Students)
    
    
